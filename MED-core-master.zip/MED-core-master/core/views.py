from django.shortcuts import render

# Create your views here.
from core.models import Obrashenie


def render_home(request):
    obrashenie=Obrashenie.objects.all()
    return render(
        request,
        'core/home.html',{'obrashenie':obrashenie})
def render_form(request):
    return render(
        request,
        'core/form_add.html')